pen = pg.mkPen(color=(255, 0, 0), width=15, style=QtCore.Qt.DashLine)
