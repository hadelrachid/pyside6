from PySide6.QtGui import QPalette
palette = QPalette()